const mysql = require('mysql2');

    exports.handler = async (event) => {
        // Extract environment variables for MySQL connection
        const host = process.env.DB_HOST;
        const user = process.env.DB_USER;
        const password = process.env.DB_PASSWORD;
        const database = process.env.DB_DATABASE;
    
        // Create a connection pool
        const pool = mysql.createPool({
            host: host,
            user: user,
            password: password,
            database: database,
            waitForConnections: true,
            connectionLimit: 10,
            queueLimit: 0,
        });
    
        // Perform a sample query
        try {
            const [rows] = await pool.promise().query('SELECT * FROM products');
            console.log('Query Result:', rows);
    
            // Your logic goes here
    
            return {
                statusCode: 200,
                body: JSON.stringify({ message: 'Successfully connected to the RDS MySQL database!' }),
            };
        } catch (error) {
            console.error('Error executing query:', error);
    
            return {
                statusCode: 500,
                body: JSON.stringify({ error: 'Internal Server Error' }),
            };
        } finally {
            // Release the connection pool when done
            pool.end();
        };
    };
        