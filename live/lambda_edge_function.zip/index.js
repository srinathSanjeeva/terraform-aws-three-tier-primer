const axios = require('axios');

exports.handler = async (event) => {
    try {
        // API to be invoked.
        const apiUrl = process.env.API_URL || 'https://jsonplaceholder.typicode.com/todos/1';

        // Make an HTTP GET request to the API
        const response = await axios.get(apiUrl);

        // Log the response data for demonstration purposes
        console.log('API Response:', response.data);

        // Return a response to the client
        return {
            statusCode: 200,
            body: JSON.stringify({ message: 'Lambda@Edge function executed successfully' }),
        };
    } catch (error) {
        console.error('Error:', error);

        // Return an error response to the client
        return {
            statusCode: 500,
            body: JSON.stringify({ error: 'Internal Server Error' }),
        };
    }
};
